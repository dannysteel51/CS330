#include <GLEW/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <glm/glm/glm.hpp>
#include <glm/glm/gtc/matrix_transform.hpp>
#include <glm/glm/gtc/type_ptr.hpp>
#include <cmath>

#include <SOIL2/SOIL2.h>

using namespace std;

int width, height;

GLuint mugVBO, handleVBO, planeVBO, mugVAO, handleVAO, planeVAO,
cupVBO, cupVAO, lampVBO, lampEBO, lampVAO, keyboardVBO, keyboardVAO,
cubeVBO, cubeVAO, mouseVBO, mouseVAO; // VAO variables

float camX, camY, camZ; // view or camera location (x,y,z)
float triLocX, triLocY, triLocZ; // triangle location (x,y,z)
float TRILOCX, TRILOCY, TRILOCZ; //second location (x,y,z)
float planeX, planeY, planeZ;
float cupX, cupY, cupZ;
float keyboardX, keyboardY, keyboardZ;
float cubeX, cubeY, cubeZ;
float mouseX, mouseY, mouseZ;
GLuint mvLoc, projLoc; // mvp uniform reference variables
GLint lampModelViewLoc, lampProjLoc;
GLint objectColorLoc, lightColorLoc, viewPosLoc;
GLint lightPosLoc;
float aspectRatio; // for p matrix aspect ratio
glm::mat4 pMat, vMat, mMat, mvMat; // mvp variables
GLuint shaderProgram; // for compiled shaders
GLuint lampShaderProgram;
bool isPerspective = true;

// Camera Field of View
GLfloat fov = 45.0f;

// Boolean array for keys and mouse buttons
bool keys[1024], mouseButtons[3];

// Input state booleans
bool isPanning = false, isOrbiting = false;

// Pitch and Yaw
GLfloat radius = 3.0f, rawYaw = 0.0f, rawPitch = 0.0f, degYaw, degPitch;

GLfloat deltaTime = 0.0f;
GLfloat lastFrame = 0.0f;
GLfloat lastX = 320, lastY = 240, xChange, yChange; // Center mouse cursor
bool firstMouseMove = true;

// Array for triangle rotations
glm::float32 triRotations[] = { 0.0f, 60.0f, 120.0f, 180.0f, 240.0f, 300.0f };

// Forward declaring of functions
static GLuint CreateShaderProgram(const string& vertexShader, const string& fragmentShader);
static GLuint CompileShader(const string& source, GLuint shaderType);
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mode);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mode);
void draw(GLFWwindow* window, double currentTime);
void PrintShaderCompileError(GLuint shader);
void PrintShaderLinkingError(int prog);
void exitScreen(GLFWwindow* window);
void processInput(GLFWwindow* window);
//void initiateCamera();
void CreateVertices();
bool IsOpenGLError();
void initPositions();
void DrawMugHandle();
void DrawPlane();
void DrawMug();
void DrawCup();
void DrawLamp();
void DrawMouse();
void DrawKeyboard();

// Define Camera Attributes
glm::vec3 cameraPosition = glm::vec3(0.0f, 0.0f, 3.0f); // Move 3 units back in z towards screen
glm::vec3 target = glm::vec3(0.0f, 0.0f, 0.0f); // What the camera points to
glm::vec3 cameraDirection = glm::normalize(cameraPosition - target); // direction z
glm::vec3 worldUp = glm::vec3(0.0, 1.0f, 0.0f);
glm::vec3 cameraRight = glm::normalize(glm::cross(worldUp, cameraDirection));// right vector x
glm::vec3 cameraUp = glm::normalize(glm::cross(cameraDirection, cameraRight)); // up vector y
glm::vec3 CameraFront = glm::vec3(0.0f, 0.0f, -1.0f); // 1 unit away from lense

//Light source positioin
glm::vec3 lightPosition(12.0f, 5.0f, 1.0f);


int main(void)
{
	width = 640; height = 480;

	GLFWwindow* window;

	/* Initialize the library */
	if (!glfwInit())
		return -1;

	/* Create a windowed mode window and its OpenGL context */
	window = glfwCreateWindow(width, height, "Main Window", NULL, NULL);
	if (!window)
	{
		glfwTerminate();
		return -1;
	}

	glfwSwapInterval(1); // VSync operation

	/* Make the window's context current */
	glfwMakeContextCurrent(window);

	/*
	*
	* Set input callback functions
	*
	*/
	glfwSetKeyCallback(window, key_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);
	glfwSetScrollCallback(window, scroll_callback);


	// Initialize GLEW
	if (glewInit() != GLEW_OK)
		cout << "Error!" << endl;

	initPositions();// Set up view (camera) and triangle initial positions

	CreateVertices(); // Generate vertices, create VAO, create buffers, associate VAO with VBO, load vertices to VBOs, associate VBOs with VAs (Vertex Attributes)


	// Write vertex shader source code
	string vertexShaderSource =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;"
		"layout(location = 1) in vec3 aColor;"
		"layout(location = 2) in vec2 texCoord;"
		"layout(location = 3) in vec3 normal;"
		"out vec3 v_color;"
		"out vec2 v_texCoord;"
		"out vec3 v_normal;"
		"out vec3 fragPos;"
		"uniform mat4 mv_matrix;"
		"uniform mat4 proj_matrix;"
		"void main()\n"
		"{\n"
		"gl_Position = proj_matrix * mv_matrix * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
		" v_color = aColor;"
		" v_texCoord = texCoord;"
		" v_normal = mat3(transpose(inverse(mv_matrix))) * normal;"
		" fragPos = vec3(mv_matrix * vec4(vPosition, 1.0f));"
		"}\n";

	// Write fragment shader source code
	string fragmentShaderSource =
		"#version 330 core\n"
		"in vec3 v_color;"
		"in vec2 v_texCoord;"
		"in vec3 v_normal;"
		"in vec3 fragPos;"
		"out vec4 fragColor;"
		"uniform sampler2D myTexture;"
		"uniform vec3 objectColor;"
		"uniform vec3 lightColor;"
		"uniform mat4 mv_matrix;"
		"uniform mat4 proj_matrix;"
		"uniform vec3 lightPos;"
		"uniform vec3 viewPos;"
		"void main()\n"
		"{\n"

		"//Ambient\n"
		"float ambientStrength = 0.3f;"
		"vec3 ambient = ambientStrength * lightColor;"

		"//Diffuse\n"
		"vec3 norm = normalize(v_normal);"
		"vec3 lightDir = normalize(lightPos - fragPos);"
		"float diff = max(dot(norm, lightDir), 0.0);"
		"vec3 diffuse = diff * lightColor;"

		"//Specularity\n"
		"float specularStrength = 1.5f;"
		"vec3 viewDir = normalize(viewPos - fragPos);"
		"vec3 reflectDir = reflect(-lightDir, norm);"
		"float spec = pow(max(dot(viewDir, reflectDir), 0.0), 128);"
		"vec3 specular = specularStrength * spec * lightColor;"

		"vec3 result = (ambient + diffuse + specular) * objectColor;"
		"fragColor = texture(myTexture, v_texCoord) * vec4(result, 1.0f);"
		"}\n";

	// Lamp vertex shader source code
	string lampVertexShaderSource =
		"#version 330 core\n"
		"layout(location = 0) in vec3 vPosition;"
		"uniform mat4 mv_matrix;"
		"uniform mat4 proj_matrix;"
		"void main()\n"
		"{\n"
		"gl_Position = proj_matrix * mv_matrix * vec4(vPosition.x, vPosition.y, vPosition.z, 1.0);"
		"}\n";

	// Lamp fragment shader source code
	string lampFragmentShaderSource =
		"#version 330 core\n"
		"out vec4 fragColor;"
		"void main()\n"
		"{\n"
		"fragColor = vec4(1.0f);"
		"}\n";

	// Create shader (program object)
	shaderProgram = CreateShaderProgram(vertexShaderSource, fragmentShaderSource);
	lampShaderProgram = CreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource);


	/* Loop until the user closes the window */
	while (!glfwWindowShouldClose(window))
	{

		GLfloat currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		processInput(window);

		glClearColor(0.00f, 0.0f, 0.0f, 1.0f);

		// Press escape to exit screen
		exitScreen(window);

		// Resize window and graphics simultaneously
		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);

		// Draw primitives
		draw(window, glfwGetTime());

		/* Swap front and back buffers */
		glfwSwapBuffers(window); // VSync operation

		/* Poll for and process events */
		glfwPollEvents(); // Detect keyboard and mouse input
	}

	glfwTerminate();
	return 0;
}

/* GLSL Error Checking Definitions */
void PrintShaderCompileError(GLuint shader)
{
	int len = 0;
	int chWritten = 0;
	char* log;
	glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &len);
	if (len > 0)
	{
		log = (char*)malloc(len);
		glGetShaderInfoLog(shader, len, &chWritten, log);
		cout << "Shader Compile Error: " << log << endl;
		free(log);
	}
}


void PrintShaderLinkingError(int prog)
{
	int len = 0;
	int chWritten = 0;
	char* log;
	glGetProgramiv(prog, GL_INFO_LOG_LENGTH, &len);
	if (len > 0)
	{
		log = (char*)malloc(len);
		glGetShaderInfoLog(prog, len, &chWritten, log);
		cout << "Shader Linking Error: " << log << endl;
		free(log);
	}
}


bool IsOpenGLError()
{
	bool foundError = false;
	int glErr = glGetError();
	while (glErr != GL_NO_ERROR)
	{
		cout << "glError: " << glErr << endl;
		foundError = true;
		glErr = glGetError();
	}
	return foundError;
}

/* GLSL Error Checking Definitions End Here */


void DrawMouse()
{
	// Load Textures
	int cupTextWidth, cupTextHeight;
	unsigned char* cupImage = SOIL_load_image("black-copy.png", &cupTextWidth, &cupTextHeight, 0, SOIL_LOAD_RGB);

	// Generate textures
	GLuint cupTexture;
	glGenTextures(1, &cupTexture);
	glBindTexture(GL_TEXTURE_2D, cupTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, cupTextWidth, cupTextHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, cupImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(cupImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	glBindTexture(GL_TEXTURE_2D, cupTexture);
	glBindVertexArray(mouseVAO); // Activate VAO (now references VBO and VA association) Can be placed anywhere before glDrawArrays()
	// Use loop to build Model matrix for triangle
	for (int i = 0; i < 6; i++) {
		// Apply Transform to model // Build model matrix for tri
		glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(.5f, 0.5f, 0.5f));
		mMat = glm::translate(glm::mat4(1.0f), glm::vec3(mouseX, mouseY, mouseZ)); // Position strip at 0,0,0
		mMat = glm::rotate(mMat, glm::radians(30.f), glm::vec3(1.0f, 1.0f, 0.0f)); // Rotate strip 60 deg on x (z is now almost upright, and y rotates toward z)
		mMat = glm::rotate(mMat, glm::radians(triRotations[i]), glm::vec3(0.0f, 0.0f, 1.0f)); // Rotate strip on z by increments in array		
		mvMat = vMat * mMat * scale; // view and model matrix multiplied here (instead of in shader for better performance)

		//Copy perspective and MV matrices to uniforms
		glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

		glEnable(GL_DEPTH_TEST); // Z-buffer operation
		glDepthFunc(GL_LEQUAL); // Used with Depth test
		//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); // Wireframe
		glDrawArrays(GL_TRIANGLES, 0, 9); // Render primitive or execute shader per draw


	}
	glBindVertexArray(0);// Optional unbinding but recommended
}


void DrawLamp() //This is the ambient/diffuse/specular lighting placeholder
{
	glBindVertexArray(lampVAO); // Activate VAO (now references VBO and VA association) Can be placed anywhere before glDrawArrays()
	// Use loop to build Model matrix for triangle
	for (int i = 0; i < 6; i++) {
		// Apply Transform to model // Build model matrix for tri
		glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(.5f, 0.5f, 0.5f));
		mMat = glm::translate(glm::mat4(1.0f), glm::vec3(lightPosition)); // Position strip at 0,0,0
		mMat = glm::rotate(mMat, glm::radians(-80.f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate strip 60 deg on x (z is now almost upright, and y rotates toward z)
		mMat = glm::rotate(mMat, glm::radians(triRotations[i]), glm::vec3(0.0f, 0.0f, 1.0f)); // Rotate strip on z by increments in array		
		mvMat = vMat * mMat * scale; // view and model matrix multiplied here (instead of in shader for better performance)

		//Copy perspective and MV matrices to uniforms
		glUniformMatrix4fv(lampModelViewLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
		glUniformMatrix4fv(lampProjLoc, 1, GL_FALSE, glm::value_ptr(pMat));

		glEnable(GL_DEPTH_TEST); // Z-buffer operation
		glDepthFunc(GL_LEQUAL); // Used with Depth test
		//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); // Wireframe
		glDrawArrays(GL_TRIANGLES, 0, 9); // Render primitive or execute shader per draw

	}
	glBindVertexArray(0);// Optional unbinding but recommended

	//glUniformMatrix4fv(lampModelViewLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	//glUniformMatrix4fv(lampProjLoc, 1, GL_FALSE, glm::value_ptr(pMat));
}

void DrawMug()
{
	// Load Textures
	int cupTextWidth, cupTextHeight;
	unsigned char* cupImage = SOIL_load_image("white.png", &cupTextWidth, &cupTextHeight, 0, SOIL_LOAD_RGB);

	// Generate textures
	GLuint cupTexture;
	glGenTextures(1, &cupTexture);
	glBindTexture(GL_TEXTURE_2D, cupTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, cupTextWidth, cupTextHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, cupImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(cupImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	glBindTexture(GL_TEXTURE_2D, cupTexture);
	glBindVertexArray(mugVAO); // Activate VAO (now references VBO and VA association) Can be placed anywhere before glDrawArrays()
	// Use loop to build Model matrix for triangle
	for (int i = 0; i < 6; i++) {
		// Apply Transform to model // Build model matrix for tri
		mMat = glm::translate(glm::mat4(1.0f), glm::vec3(triLocX, triLocY, triLocZ)); // Position strip at 0,0,0
		mMat = glm::rotate(mMat, glm::radians(-80.f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate strip 60 deg on x (z is now almost upright, and y rotates toward z)
		mMat = glm::rotate(mMat, glm::radians(triRotations[i]), glm::vec3(0.0f, 0.0f, 1.0f)); // Rotate strip on z by increments in array		
		mvMat = vMat * mMat; // view and model matrix multiplied here (instead of in shader for better performance)

		//Copy perspective and MV matrices to uniforms
		glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

		glEnable(GL_DEPTH_TEST); // Z-buffer operation
		glDepthFunc(GL_LEQUAL); // Used with Depth test
		//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); // Wireframe
		glDrawArrays(GL_TRIANGLES, 0, 9); // Render primitive or execute shader per draw


	}
	glBindVertexArray(0);// Optional unbinding but recommended
}

void DrawCup()
{
	// Load Textures
	int cupTextWidth, cupTextHeight;
	unsigned char* cupImage = SOIL_load_image("redPlastic.png", &cupTextWidth, &cupTextHeight, 0, SOIL_LOAD_RGB);

	// Generate textures
	GLuint cupTexture;
	glGenTextures(1, &cupTexture);
	glBindTexture(GL_TEXTURE_2D, cupTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, cupTextWidth, cupTextHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, cupImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(cupImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	glBindTexture(GL_TEXTURE_2D, cupTexture);
	glBindVertexArray(mugVAO); // Activate VAO (now references VBO and VA association) Can be placed anywhere before glDrawArrays()
	// Use loop to build Model matrix for triangle
	for (int i = 0; i < 6; i++) {
		// Apply Transform to model // Build model matrix for tri
		glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(1.0, 1.0, 1.55));
		mMat = glm::translate(glm::mat4(1.0f), glm::vec3(cupX, cupY, cupZ)); // Position strip at 0,0,0
		mMat = glm::rotate(mMat, glm::radians(-80.f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate strip 60 deg on x (z is now almost upright, and y rotates toward z)
		mMat = glm::rotate(mMat, glm::radians(triRotations[i]), glm::vec3(0.0f, 0.0f, 1.0f)); // Rotate strip on z by increments in array		
		mvMat = vMat * mMat * scale; // view and model matrix multiplied here (instead of in shader for better performance)

		//Copy perspective and MV matrices to uniforms
		glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

		glEnable(GL_DEPTH_TEST); // Z-buffer operation
		glDepthFunc(GL_LEQUAL); // Used with Depth test
		//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); // Wireframe
		glDrawArrays(GL_TRIANGLES, 0, 9); // Render primitive or execute shader per draw


	}
	glBindVertexArray(0);// Optional unbinding but recommended
}

void DrawMugHandle()
{
	// Load Textures
	int cupTextWidth, cupTextHeight;
	unsigned char* cupImage = SOIL_load_image("white.png", &cupTextWidth, &cupTextHeight, 0, SOIL_LOAD_RGB);

	// Generate textures
	GLuint cupTexture;
	glGenTextures(1, &cupTexture);
	glBindTexture(GL_TEXTURE_2D, cupTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, cupTextWidth, cupTextHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, cupImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(cupImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	glBindTexture(GL_TEXTURE_2D, cupTexture);
	glBindVertexArray(handleVAO); // Activate VAO (now references VBO and VA association) Can be placed anywhere before glDrawArrays()
	// Use loop to build Model matrix for triangle
	for (int i = 0; i < 6; i++) {
		// Apply Transform to model // Build model matrix for tri

		glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(0.65f, 0.65f, 0.25f));
		mMat = glm::translate(glm::mat4(1.0f), glm::vec3(TRILOCX, TRILOCY, TRILOCZ)); // Position strip at 3.0,-3.0,0
		mMat = glm::rotate(mMat, glm::radians(25.0f), glm::vec3(1.0f, 0.0f, 0.0f)); // Rotate strip 60 deg on x (z is now almost upright, and y rotates toward z)
		mMat = glm::rotate(mMat, glm::radians(triRotations[i]), glm::vec3(0.0f, 0.0f, 1.0f)); // Rotate strip on z by increments in array
		mvMat = vMat * mMat * scale; // view and model matrix multiplied here (instead of in shader for better performance)

		//Copy perspective and MV matrices to uniforms
		glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));

		glEnable(GL_DEPTH_TEST); // Z-buffer operation
		glDepthFunc(GL_LEQUAL); // Used with Depth test
		//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); // Wireframe
		glDrawArrays(GL_TRIANGLES, 0, 9); // Render primitive or execute shader per draw
	}

	glBindVertexArray(0);// Optional unbinding but recommended
}

void DrawPlane()
{
	// Load Textures
	int gridTextWidth, gridTextHeight;
	unsigned char* gridImage = SOIL_load_image("crate.png", &gridTextWidth, &gridTextHeight, 0, SOIL_LOAD_RGB);

	// Generate textures
	GLuint gridTexture;
	glGenTextures(1, &gridTexture);
	glBindTexture(GL_TEXTURE_2D, gridTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, gridTextWidth, gridTextHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, gridImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(gridImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	glBindTexture(GL_TEXTURE_2D, gridTexture);
	glBindVertexArray(handleVAO);

	glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(55.0f, 0.5f, 5.0f));
	mMat = glm::translate(glm::mat4(1.0f), glm::vec3(planeX, planeY, planeZ)); // Position strip at 3.0,-3.0,0
	mMat = glm::rotate(mMat, glm::radians(15.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	mvMat = vMat * mMat * scale;

	glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));


	glEnable(GL_DEPTH_TEST); // Z-buffer operation
	glDepthFunc(GL_LEQUAL); // Used with Depth test
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); // Wireframe
	glDrawArrays(GL_TRIANGLES, 0, 9); // Render primitive or execute shader per draw
	glBindVertexArray(0);// Optional unbinding but recommended
}

void DrawKeyboard()
{
	// Load Textures
	int gridTextWidth, gridTextHeight;
	unsigned char* gridImage = SOIL_load_image("blackPlastic.png", &gridTextWidth, &gridTextHeight, 0, SOIL_LOAD_RGB);

	// Generate textures
	GLuint gridTexture;
	glGenTextures(1, &gridTexture);
	glBindTexture(GL_TEXTURE_2D, gridTexture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, gridTextWidth, gridTextHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, gridImage);
	glGenerateMipmap(GL_TEXTURE_2D);
	SOIL_free_image_data(gridImage);
	glBindTexture(GL_TEXTURE_2D, 0);

	glBindTexture(GL_TEXTURE_2D, gridTexture);
	glBindVertexArray(handleVAO);

	glm::mat4 scale = glm::scale(glm::mat4(1.0f), glm::vec3(20.0f, 0.5f, 1.35f));
	mMat = glm::translate(glm::mat4(1.0f), glm::vec3(keyboardX, keyboardY, keyboardZ)); // Position strip at 3.0,-3.0,0
	mMat = glm::rotate(mMat, glm::radians(15.0f), glm::vec3(1.0f, 0.0f, 0.0f));
	mvMat = vMat * mMat * scale;

	glUniformMatrix4fv(mvLoc, 1, GL_FALSE, glm::value_ptr(mvMat));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(pMat));


	glEnable(GL_DEPTH_TEST); // Z-buffer operation
	glDepthFunc(GL_LEQUAL); // Used with Depth test
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); // Wireframe
	glDrawArrays(GL_TRIANGLES, 0, 9); // Render primitive or execute shader per draw
	glBindVertexArray(0);// Optional unbinding but recommended
}

/*Draw Primitive(s)*/
void draw(GLFWwindow* window, double currentTime)
{
	glClear(GL_DEPTH_BUFFER_BIT); // Z-buffer operation (hsr removal)
	glClear(GL_COLOR_BUFFER_BIT); // remove animation trails

	glUseProgram(shaderProgram); // load shaders to GPU

	// Reference matrix uniform variables in shader
	mvLoc = glGetUniformLocation(shaderProgram, "mv_matrix");
	projLoc = glGetUniformLocation(shaderProgram, "proj_matrix");

	// Get light and object color, and light position location
	objectColorLoc = glGetUniformLocation(shaderProgram, "objectColor");
	lightColorLoc = glGetUniformLocation(shaderProgram, "lightColor");
	lightPosLoc = glGetUniformLocation(shaderProgram, "lightPos");
	viewPosLoc = glGetUniformLocation(shaderProgram, "viewPos");

	// Assign light and object colors
	/*glUniform3f(objectColorLoc, 0.46f, 0.36f, 0.25f);*/
	glUniform3f(objectColorLoc, 0.56f, 0.56f, 0.55f);
	glUniform3f(lightColorLoc, 1.0f, 1.0f, 1.0f);

	// Set light poisition
	glUniform3f(lightPosLoc, lightPosition.x, lightPosition.y, lightPosition.z);

	// specify view position
	glUniform3f(viewPosLoc, camX, camY, camZ);

	// Build Perspective matrix
	glfwGetFramebufferSize(window, &width, &height);
	aspectRatio = (float)width / (float)height;

	// This is how you switch from perspective to orthogonal view
	// isPerspective is set in the constructor as true
	// If P is pressed, it is set to false and the else statement is called
	if (isPerspective)
	{
		pMat = glm::perspective(fov, aspectRatio, 0.1f, 1000.0f);
	}
	else
	{
		pMat = glm::ortho(-5.0f, 5.0f, -5.0f, 5.0f, 0.1f, 100.0f);
	}

	//Build View matrix
	vMat = glm::translate(glm::mat4(1.0f), glm::vec3(-camX, -camY, -camZ));

	DrawMug(); // calls the function for the mug

	DrawMugHandle(); // Calls the function for the mug handle

	DrawCup();

	DrawPlane();

	DrawKeyboard();

	DrawMouse();

	glUseProgram(0);

	/*
	* This is the program for the light
	*/
	glUseProgram(lampShaderProgram);

	// Reference matrix uniform variables in shader
	lampModelViewLoc = glGetUniformLocation(lampShaderProgram, "mv_matrix");
	lampProjLoc = glGetUniformLocation(lampShaderProgram, "proj_matrix");

	DrawLamp();

	glUseProgram(0);
}

// Set up view (camera) and triangle locations
void initPositions()
{
	camX = 5.0f; //
	camY = 1.0f; // The location of the camera (0, 0, 9)
	camZ = 18.0f; //
	triLocX = 0.0f; //
	triLocY = 0.0f; // The location for the mug
	triLocZ = 0.0f; //
	TRILOCX = -0.95f; //
	TRILOCY = -1.0f; // The Location for the handle
	TRILOCZ = 0.0f;  //
	planeX = -35.0f;
	planeY = -3.8f;
	planeZ = 5.0f;
	cupX = 12.0f;
	cupY = 0.75f;
	cupZ = -1.15f;
	keyboardX = -9.0f;
	keyboardY = -2.95f;
	keyboardZ = 4.5f;
	mouseX = 13.0f;
	mouseY = -3.25f,
	mouseZ = 3.5f;
}


/*Compile Shaders */
static GLuint CompileShader(const string& source, GLuint shaderType)
{
	// Create vertexShader object
	GLuint shaderID = glCreateShader(shaderType);
	const char* src = source.c_str();

	// Attach source code
	glShaderSource(shaderID, 1, &src, nullptr);

	// Compile shader
	glCompileShader(shaderID);


	/* Shader Compliation Error Check */
	GLint shaderCompiled;
	IsOpenGLError();
	glGetShaderiv(shaderID, GL_COMPILE_STATUS, &shaderCompiled);
	if (shaderCompiled != 1)
	{
		cout << "Shader Compilation Failed!" << endl;
		PrintShaderCompileError(shaderID);
	}
	/* End here */


	// Return ID
	return shaderID;
}

/* Create Shader Program*/
static GLuint CreateShaderProgram(const string& vertexShader, const string& fragmentShader)
{
	// Compile Vertex Shader
	GLint vertShaderCompiled = CompileShader(vertexShader, GL_VERTEX_SHADER);

	// Compile Fragment Shader
	GLint fragShaderCompiled = CompileShader(fragmentShader, GL_FRAGMENT_SHADER);

	// Create program object
	GLuint shaderProgram = glCreateProgram();

	// Attach shaders
	glAttachShader(shaderProgram, vertShaderCompiled);
	glAttachShader(shaderProgram, fragShaderCompiled);

	// Link shaders to create full shader program
	glLinkProgram(shaderProgram);

	/* Shader Linking Error Check */
	GLint linked;
	IsOpenGLError();
	glGetProgramiv(shaderProgram, GL_LINK_STATUS, &linked);
	if (linked != 1)
	{
		cout << "Shader Linking Failed!" << endl;
		PrintShaderLinkingError(shaderProgram);
	}
	/* End here */

	glValidateProgram(shaderProgram);

	// Delete intermediates
	glDeleteShader(vertShaderCompiled);
	glDeleteShader(fragShaderCompiled);

	return shaderProgram;
}

void CreateVertices()
{
	// Define vertex data for Triangle (GLfloat array)
	GLfloat triangleVertices[] = {
		// positon attributes (x,y,z)
		0.0f, 0.0f, 0.0f,  // vert 1
		0.60f, 0.60f, 0.60f, // black
		0.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, 0.0f, // vert 2
		0.25f, 0.40f, 0.50f, // white
		0.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 3
		0.25f, 0.35f, 0.50f,  // white
		1.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, 0.0f, // vert 4
		0.25f, 0.30f, 0.50f,  // blue
		1.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, -2.0f, // vert 5
		0.25f, 0.25f, 0.50f,  // Blue/green	
		0.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 6
		0.25f, 0.20f, 0.50f,  // Blue/ lighter green
		0.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 7
		0.25f, 0.15f, 0.50f,  // Blue/ lighter green
		1.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, -2.0f, // vert 8
		0.25f, 0.10f, 0.50f,  // Blue/ lighter green
		1.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, -2.0f, // vert 9
		0.25f, 0.05f, 0.50f,  // Blue/ lighter green
		0.0, 0.0,
		0.0f, 0.0f, 1.0f // normal postive Z
	};

	GLfloat triangle1Vertices[] = {
		 0.0f, 0.0f, 0.0f,  // vert 1
		0.10f, 0.55f, 0.30f, // black
		0.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, 0.0f, // vert 2
		0.25f, 0.40f, 0.50f, // white
		0.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 3
		0.25f, 0.35f, 0.50f, // white
		1.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, 0.0f, // vert 4
		0.25f, 0.30f, 0.50f, // blue
		1.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, -2.0f, // vert 5
		0.25f, 0.25f, 0.50f, // Blue/green	
		0.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 6
		0.25f, 0.20f, 0.50f, // Blue/ lighter green
		0.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 7
		0.25f, 0.15f, 0.50f, // Blue/ lighter green
		1.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, -2.0f, // vert 8
		0.25f, 0.10f, 0.50f, // Blue/ lighter green
		1.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, -2.0f, // vert 9
		0.25f, 0.05f, 0.50f, // Blue/ lighter green
		0.0f, 0.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

	};

	GLfloat planeVertices[] = {
		-5.0f, -5.0f, -5.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 0.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		5.0f, -5.0f, -5.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		5.0f, -5.0f, 5.0f,
		0.0f, 1.0f, 0.0f,
		1.0f, 0.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		5.0f, -5.0f, 5.0f,
		0.0f, 1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		-5.0f, -5.0f, 5.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 0.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		-5.0f, -5.0f, -5.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z
	};

	GLfloat CupVertices[] = {
		// positon attributes (x,y,z)
		0.0f, 0.0f, 0.0f,  // vert 1
		0.60f, 0.60f, 0.60f, // black
		0.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, 0.0f, // vert 2
		0.25f, 0.40f, 0.50f, // white
		0.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 3
		0.25f, 0.35f, 0.50f,  // white
		1.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, 0.0f, // vert 4
		0.25f, 0.30f, 0.50f,  // blue
		1.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, -2.0f, // vert 5
		0.25f, 0.25f, 0.50f,  // Blue/green	
		0.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 6
		0.25f, 0.20f, 0.50f,  // Blue/ lighter green
		0.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 7
		0.25f, 0.15f, 0.50f,  // Blue/ lighter green
		1.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, -2.0f, // vert 8
		0.25f, 0.10f, 0.50f,  // Blue/ lighter green
		1.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, -2.0f, // vert 9
		0.25f, 0.05f, 0.50f,  // Blue/ lighter green
		0.0, 0.0,
		0.0f, 0.0f, 1.0f // normal postive Z
	};

	GLfloat lampVertices[] = {

		0.0f, 0.0f, 0.0f,  // vert 1

		0.5f, 0.866f, 0.0f, // vert 2

		1.0f, 0.0f, 0.0f, // vert 3

		0.5f, 0.866f, 0.0f, // vert 4

		0.5f, 0.866f, -2.0f, // vert 5

		1.0f, 0.0f, 0.0f, // vert 6

		1.0f, 0.0f, 0.0f, // vert 7

		1.0f, 0.0f, -2.0f, // vert 8

		0.5f, 0.866f, -2.0f, // vert 9
	};

	GLfloat keyboardVertices[] = {
		-5.0f, -5.0f, -5.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 0.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		5.0f, -5.0f, -5.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		5.0f, -5.0f, 5.0f,
		0.0f, 1.0f, 0.0f,
		1.0f, 0.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		5.0f, -5.0f, 5.0f,
		0.0f, 1.0f, 0.0f,
		1.0f, 1.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		-5.0f, -5.0f, 5.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 0.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z

		-5.0f, -5.0f, -5.0f,
		0.0f, 1.0f, 0.0f,
		0.0f, 1.0f,
		0.0f, 0.0f, 1.0f, // normal postive Z
	};

	GLfloat mouseVertices[] = {
		0.0f, 0.0f, 0.0f,  // vert 1
		0.60f, 0.60f, 0.60f, // black
		0.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, 0.0f, // vert 2
		0.25f, 0.40f, 0.50f, // white
		0.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 3
		0.25f, 0.35f, 0.50f,  // white
		1.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, 0.0f, // vert 4
		0.25f, 0.30f, 0.50f,  // blue
		1.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, -2.0f, // vert 5
		0.25f, 0.25f, 0.50f,  // Blue/green	
		0.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 6
		0.25f, 0.20f, 0.50f,  // Blue/ lighter green
		0.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, 0.0f, // vert 7
		0.25f, 0.15f, 0.50f,  // Blue/ lighter green
		1.0, 0.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		1.0f, 0.0f, -2.0f, // vert 8
		0.25f, 0.10f, 0.50f,  // Blue/ lighter green
		1.0, 1.0,
		0.0f, 0.0f, 1.0f, // normal postive Z

		0.5f, 0.866f, -2.0f, // vert 9
		0.25f, 0.05f, 0.50f,  // Blue/ lighter green
		0.0, 0.0,
		0.0f, 0.0f, 1.0f // normal postive Z
	};



	glGenVertexArrays(1, &mugVAO); // Create VAO
	glGenBuffers(1, &mugVBO); // Create VBO
	glBindVertexArray(mugVAO); // Activate VAO for VBO association
	glBindBuffer(GL_ARRAY_BUFFER, mugVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(triangleVertices), triangleVertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(1); // Enable VA
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(2); // Enable VA
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(3); // Enable VA
	glBindVertexArray(0); // Unbind VAO (Optional but recommended)

	glGenVertexArrays(1, &handleVAO); // Create VAO
	glGenBuffers(1, &handleVBO); // Create VBO
	glBindVertexArray(handleVAO); // Activate VAO for VBO association
	glBindBuffer(GL_ARRAY_BUFFER, handleVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(triangle1Vertices), triangle1Vertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(1); // Enable VA
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(2); // Enable VA
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(3); // Enable VA
	glBindVertexArray(0); // Unbind VAO (Optional but recommended)

	glGenVertexArrays(1, &planeVAO); // Create VAO
	glGenBuffers(1, &planeVBO); // Create VBO
	glBindVertexArray(planeVAO); // Activate VAO for VBO association
	glBindBuffer(GL_ARRAY_BUFFER, planeVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(planeVertices), planeVertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(1); // Enable VA
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(2); // Enable VA
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(3); // Enable VA
	glBindVertexArray(0); // Unbind VAO (Optional but recommended)

	glGenVertexArrays(1, &cupVAO); // Create VAO
	glGenBuffers(1, &cupVBO); // Create VBO
	glBindVertexArray(cupVAO); // Activate VAO for VBO association
	glBindBuffer(GL_ARRAY_BUFFER, cupVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(CupVertices), CupVertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(1); // Enable VA
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(2); // Enable VA
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(3); // Enable VA
	glBindVertexArray(0); // Unbind VAO (Optional but recommended)

	glGenVertexArrays(1, &lampVAO); // Create VAO
	glGenBuffers(1, &lampVBO); // Create VBO
	glBindVertexArray(lampVAO); // Activate VAO for VBO association
	glBindBuffer(GL_ARRAY_BUFFER, lampVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(lampVertices), lampVertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glBindVertexArray(0); // Unbind VAO (Optional but recommended)

	glGenVertexArrays(1, &keyboardVAO); // Create VAO
	glGenBuffers(1, &keyboardVBO); // Create VBO
	glBindVertexArray(keyboardVAO); // Activate VAO for VBO association
	glBindBuffer(GL_ARRAY_BUFFER, keyboardVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(keyboardVertices), keyboardVertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(1); // Enable VA
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(2); // Enable VA
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(3); // Enable VA
	glBindVertexArray(0); // Unbind VAO (Optional but recommended)

	glGenVertexArrays(1, &mouseVAO); // Create VAO
	glGenBuffers(1, &mouseVBO); // Create VBO
	glBindVertexArray(mouseVAO); // Activate VAO for VBO association
	glBindBuffer(GL_ARRAY_BUFFER, mouseVBO); // Enable VBO	
	glBufferData(GL_ARRAY_BUFFER, sizeof(mouseVertices), mouseVertices, GL_STATIC_DRAW); // Copy Vertex data to VBO
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)0); // Associate VBO with VA (Vertex Attribute)
	glEnableVertexAttribArray(0); // Enable VA
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(3 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(1); // Enable VA
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(6 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(2); // Enable VA
	glVertexAttribPointer(3, 3, GL_FLOAT, GL_FALSE, 11 * sizeof(GLfloat), (GLvoid*)(8 * sizeof(GLfloat))); // Associate VBO with VA
	glEnableVertexAttribArray(3); // Enable VA
	glBindVertexArray(0); // Unbind VAO (Optional but recommended)
}

void exitScreen(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, true);
	}
}

void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	// set movement with WASD + QE
	// Set P to change from ortho to perspective view and back
	  // Maybe a toggle feature: !perspective == perspective each time it is pressed
	// Close window
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, GL_TRUE);

	// Assign true to Element ASCII if key pressed
	if (action == GLFW_PRESS)
		keys[key] = true;
	else if (action == GLFW_RELEASE) // Assign false to Element ASCII if key released
		keys[key] = false;

	if (keys[GLFW_KEY_P] && action == GLFW_PRESS) // When pressed it toggles the bool on and off
		isPerspective = !isPerspective;

	// Orbit camera
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButtons[GLFW_MOUSE_BUTTON_LEFT] && action == GLFW_PRESS)
		isOrbiting = true;
	else
		isOrbiting = false;
}

void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{

	// Set speed of movement
		// Clamp FOV
	if (fov >= 1.0f && fov <= 55.0f)
		fov -= yoffset * 0.01;

	// Default FOV
	if (fov < 1.0f)
		fov = 1.0f;
	if (fov > 55.0f)
		fov = 55.0f;
}

void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{

	if (firstMouseMove)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouseMove = false;
	}
	// Calculate mouse offset (Easing effect)
	xChange = xpos - lastX;
	yChange = lastY - ypos; // Inverted cam

	// Get current mouse (always starts at 0)
	lastX = xpos;
	lastY = ypos;

	// Pan camera
	//if (isPanning)
	//{
	//	if (camZ < 0)
	//		CameraFront.z = 1.f;
	//	else
	//		CameraFront.z = -1.f;

	//	GLfloat cameraSpeed = xChange * deltaTime;
	//	cameraPosition += cameraSpeed * cameraRight;

	//	cameraSpeed = yChange * deltaTime;
	//	cameraPosition += cameraSpeed * cameraUp;
	//}

	if (isOrbiting)
	{
		// Update raw yaw and pitch with mouse movement
		rawYaw += xChange;
		rawPitch += yChange;

		// Conver yaw and pitch to degrees, and clamp pitch
		degYaw = glm::radians(rawYaw);
		degPitch = glm::clamp(glm::radians(rawPitch), -glm::pi<float>() / 2.f + .1f, glm::pi<float>() / 2.f - .1f);

		// Azimuth Altitude formula
		camX = target.x + radius * cosf(degPitch) * sinf(degYaw);
		camY = target.y + radius * sinf(degPitch);
		camZ = target.z + radius * cosf(degPitch) * cosf(degYaw);
	}

	// Moves the screen with the mouse (offset)
	if (xChange)
	{
		camX += (xChange * 0.1);
	}
	else if (yChange)
	{
		camY += yChange * 0.1;
	}
}
/* Directs the camera with movement from the mouse*/


void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	// Detect mouse button clicks
	if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS)
	{
		cout << "Left mouse button pressed" << endl;
	}

	if (button == GLFW_MOUSE_BUTTON_MIDDLE && action == GLFW_PRESS)
	{
		cout << "Middle mouse button pressed" << endl;
	}

	if (button == GLFW_MOUSE_BUTTON_RIGHT && action == GLFW_PRESS)
	{
		cout << "Right mouse button pressed" << endl;
	}
}

// Define TransformCamera function
void TransformCamera()
{
	// Pan camera
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButtons[GLFW_MOUSE_BUTTON_MIDDLE])
		isPanning = true;
	else
		isPanning = false;

	// Orbit camera
	if (keys[GLFW_KEY_LEFT_ALT] && mouseButtons[GLFW_MOUSE_BUTTON_LEFT])
		isOrbiting = true;
	else
		isOrbiting = false;
}


void processInput(GLFWwindow* window)
{

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
	{
		camZ += -0.5;
	}
	else if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
	{
		camZ += 0.5;
	}
	else if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
	{
		camX += -0.5;
	}
	else if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
	{
		camX += 0.5;
	}
	else if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
	{
		camY += 0.5;
	}
	else if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
	{
		camY += -0.5;
	}

}